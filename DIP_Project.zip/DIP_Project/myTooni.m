function myTooni
    inputImage = im2double(imread('balloons_noisy.png'));
    [rows,cloumns,channels] = size(inputImage);
    figure, imshow(inputImage);
    smoothImage = inputImage;
    if(channels==3)
        smoothImage = rgb2lab(inputImage);
    end
    for i = 1:15
        smoothImage = imbilatfilt(smoothImage,12,2);
    end
    if(channels==3)
        smoothImage = lab2rgb(smoothImage);
    end   
    for c = 1:channels
        smoothImage(:,:,c) = medfilt2(smoothImage(:,:,c), [7 7]);
        inputImage(:,:,c) = medfilt2(inputImage(:,:,c), [7 7]);
    end
    figure,imshow(smoothImage);
    if(channels==3)
        inputImage = rgb2gray(inputImage);
    end
    rslt=edge(inputImage,'canny',0.1);
    rslt = imcomplement(rslt);
    final = smoothImage.*rslt;
    figure,imshow(final);
end