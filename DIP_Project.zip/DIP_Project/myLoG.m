function [outputImage] = myLoG(inputImage,filterSize,sigma)
    x = floor(filterSize/2);
    [rows,columns,channels] = size(inputImage);
    outputImage = zeros(rows,columns,channels);
%     LoG = zeros(filterSize,filterSize);
%     sigmaSq = (sigma^2)/2;
%     for i = 1:filterSize
%         for j = 1:filterSize
%             z = ((x+1-i)^2 + (x+1-j)^2)/(4*sigmaSq);
%             LoG(i,j) = (((i^2 + j^2)/(4*(sigmaSq^2))) - (1/sigmaSq))*exp(-z);
%         end
%     end
    LoG = [0,0,-1,0,0;0,-1,-2,-1,0;-1,-2,16,-2,-1;0,-1,-2,-1,0;0,0,-1,0,0];
    for c = 1:channels
        outputImage(:,:,c) = conv2(inputImage(:,:,c),LoG,'same');
        outputImage(:,:,c) = outputImage(:,:,c) + inputImage(:,:,c);
    end
    
end