clear all;
inputImage = im2double(imread('balloons_noisy.png'));
[rows,cloumns,channels] = size(inputImage);
outputImage1 = inputImage;
if(channels==3)
    outputImage1 = rgb2lab(outputImage1);
end
% outputImage1 = myMedianFilter(inputImage,7);
for i = 1:15
    outputImage2 = myBilateralFilter(outputImage1,7,2,12);
    outputImage1 = outputImage2;
end
if(channels==3)
    outputImage2 = lab2rgb(outputImage2);
end
outputImage3 = myMedianFilter(outputImage2,7);
% outputImage3(:,:,1) = medfilt2(outputImage2(:,:,1),[7,7]);
% outputImage3(:,:,2) = medfilt2(outputImage2(:,:,2),[7,7]);
% outputImage3(:,:,3) = medfilt2(outputImage2(:,:,3),[7,7]);
% figure,imshow(inputImage);
% figure,imshow(outputImage1);
% figure,imshow(outputImage2);
% figure,imshow(outputImage3);
inputImage = myMedianFilter(inputImage,7);
% inputImage(:,:,1) = medfilt2(inputImage(:,:,1),[7,7]);
% inputImage(:,:,2) = medfilt2(inputImage(:,:,2),[7,7]);
% inputImage(:,:,3) = medfilt2(inputImage(:,:,3),[7,7]);
outputImage = myCannyEdgeDetector(inputImage);
outputImage = imcomplement(outputImage);
new = outputImage3.*outputImage;
figure,imshow(outputImage3);
% figure,imshow(outputImage2);
figure,imshow(new);
outputImage