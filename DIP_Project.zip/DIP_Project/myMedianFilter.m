function [outputImage] = myMedianFilter(inputImage,filterSize)
    [rows,columns,channels] = size(inputImage);
    outputImage = zeros(rows,columns,channels);
    x = floor(filterSize/2);
    zeroPaddedImage = zeros(rows+(2*x),columns+(2*x),channels);
    for c = 1:channels
        zeroPaddedImage(x+1:end-x,x+1:end-x,c) = inputImage(:,:,c);
    end
    for c = 1:channels
        for i = 1:rows
            for j = 1:columns
                a = sort(reshape(zeroPaddedImage(i:i+filterSize-1,j:j+filterSize-1,c),filterSize^2,1));
%                 zeroPaddedImage(i+x,j+x,c) = a(ceil((filterSize^2)/2));
                outputImage(i,j,c) = a(ceil((filterSize^2)/2));
            end
        end
    end
%     for c = 1:channels
%         outputImage(:,:,c) = zeroPaddedImage(x+1:end-x,x+1:end-x,c);
%     end
end