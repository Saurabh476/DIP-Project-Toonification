function [outputImage] = myBilateralFilter(inputImage,filterSize,sigmaS,sigmaI)
    [rows,columns,channels] = size(inputImage);
    outputImage = zeros(rows,columns,channels);
    x = floor(filterSize/2);
    zeroPaddedImage = zeros(rows+(2*x),columns+(2*x),channels);
    for c = 1:channels
        zeroPaddedImage(x+1:end-x,x+1:end-x,c) = inputImage(:,:,c);
    end
    spatialFilter = zeros(filterSize,filterSize);
%     intensityFilter = zeros(filterSize,filterSize);
    for i=-x:x
        for j=-x:x
            spatialFilter(i+x+1,j+x+1) = (i^2 +j^2);
        end
    end
    spatialFilter = spatialFilter./(2*sigmaS);
    spatialFilter = exp(-spatialFilter);
    
    for c = 1:channels
        for i = 1:rows-x
            for j = 1:columns-x
                intensityFilter = zeroPaddedImage(i:i+filterSize-1,j:j+filterSize-1,c)-zeroPaddedImage(i+x,j+x,c);
                intensityFilter = (intensityFilter.^2)./(2*sigmaI);
                intensityFilter = exp(-intensityFilter);
                W = spatialFilter.*intensityFilter;
                zeroPaddedImage(i+x,j+x,c) = sum((zeroPaddedImage(i:i+filterSize-1,j:j+filterSize-1,c).*W),'all')/sum(W,'all');
            end
        end
    end
    for c = 1:channels
        outputImage(:,:,c) = zeroPaddedImage(x+1:end-x,x+1:end-x,c);
    end
end