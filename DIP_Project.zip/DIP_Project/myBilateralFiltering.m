function [out_array , corrupt ] = myBilateralFiltering(in_array , sigma_s , sigma_r)
    windowsize = 2*3*ceil(sigma_s) + 1;
    out_array = in_array;
    [rows,columns] = size(in_array);
%     noise = randn(rows,columns);
%     noise = noise .* 0.05;
%     corrupt = in_array + noise;
    corrupt = in_array;
    tileRows = rows;
    tileColumns = columns;
    for i=1:rows
        for j=1:columns
            intensity = 0;
            weight = 0;
            tileX = i - (windowsize - 1)/2;
            tilelimitX = windowsize;
            while tilelimitX > 0
                tileY = j - (windowsize - 1)/2;
                tilelimitY = windowsize;
                while tilelimitY > 0
                    %
                    if(tileX > 0 && tileX < tileRows && tileY > 0 && tileY < tileColumns)
                        %main calculation...............
                        gpx = i-tileX;
                        gpy = j-tileY;
                        intensitydiff = double(corrupt(tileX,tileY) - corrupt(i,j));
                        domain_filter = exp(-(gpx.^2+gpy.^2)/(2*sigma_s^2));
                        range_filter = exp(-intensitydiff.^2/(2*sigma_r^2));
                        filter = domain_filter.*range_filter;
                        intensity = intensity + filter*corrupt(tileX,tileY);
                        weight = weight + filter;
                        %...............................
                    end
                    tileY = tileY + 1;
                    tilelimitY = tilelimitY - 1;
                    %
                end
                tileX = tileX + 1;
                tilelimitX = tilelimitX - 1;
            end
            out_array(i,j) = intensity./weight;
            
        end
    end
end
